<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Pobierz wykonane testy
$sql_tests = "SELECT t.name AS test_name, p.completion, p.date_completed 
              FROM progress p 
              JOIN tests t ON p.test_id = t.id 
              WHERE p.user_id = ?";
$stmt = $conn->prepare($sql_tests);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_tests = $stmt->get_result();

// Pobierz osiągnięcia
$sql_achievements = "SELECT name, description, category, level, points, earned_at 
                     FROM achievements 
                     WHERE user_id = ?";
$stmt = $conn->prepare($sql_achievements);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_achievements = $stmt->get_result();

// Pobierz ranking użytkowników na podstawie punktów
$sql_ranking = "SELECT u.name AS user_name, SUM(a.points) AS total_points 
                FROM users u 
                JOIN achievements a ON u.id = a.user_id 
                GROUP BY u.id 
                ORDER BY total_points DESC 
                LIMIT 10";
$ranking_results = $conn->query($sql_ranking);

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twoje postępy i osiągnięcia</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card {
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        .btn-custom {
            font-size: 1.1rem;
            font-weight: 600;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
        table {
            background: rgba(255, 255, 255, 0.9);
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../panel.php">← Powrót do panelu głównego</a>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../users/logout.php">Wyloguj się</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center mb-4">Twoje postępy i osiągnięcia</h1>

        <!-- Sekcja: Wykonane testy -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Wykonane testy</h5>
                        <?php if ($result_tests->num_rows > 0): ?>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Nazwa testu</th>
                                        <th>Procent ukończenia</th>
                                        <th>Data ukończenia</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($row = $result_tests->fetch_assoc()): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($row['test_name']); ?></td>
                                            <td><?= htmlspecialchars($row['completion']); ?>%</td>
                                            <td><?= htmlspecialchars($row['date_completed']); ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p>Brak wykonanych testów.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sekcja: Osiągnięcia -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Twoje osiągnięcia</h5>
                        <?php if ($result_achievements->num_rows > 0): ?>
                            <div class="row">
                                <?php while ($row = $result_achievements->fetch_assoc()): ?>
                                    <div class="col-md-4 text-center">
                                        <img src="../images/<?= strtolower($row['level']); ?>.png" alt="<?= $row['level']; ?>" class="img-fluid" style="max-width: 100px;">
                                        <h5><?= htmlspecialchars($row['name']); ?></h5>
                                        <p><?= htmlspecialchars($row['description']); ?></p>
                                        <span class="badge bg-primary"><?= $row['category']; ?></span>
                                        <span class="badge bg-success"><?= $row['level']; ?></span>
                                        <p class="text-muted">Zdobyto: <?= htmlspecialchars($row['earned_at']); ?></p>
                                        <p><strong>Punkty:</strong> <?= $row['points']; ?></p>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p>Brak osiągnięć do wyświetlenia.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Sekcja: Ranking -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ranking użytkowników</h5>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Miejsce</th>
                                    <th>Użytkownik</th>
                                    <th>Punkty</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $place = 1; ?>
                                <?php while ($row = $ranking_results->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= $place++; ?></td>
                                        <td><?= htmlspecialchars($row['user_name']); ?></td>
                                        <td><?= htmlspecialchars($row['total_points']); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mt-4">
            <a href="../panel.php" class="btn btn-primary">Powrót do panelu głównego</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
