<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$comment_id = $_GET['id'] ?? null;

if (!$comment_id) {
    header("Location: forum.php?message=Brak ID komentarza.");
    exit();
}

// Sprawdź, czy użytkownik ma prawo usunąć komentarz
$sql_check = "SELECT c.user_id AS comment_author_id, p.user_id AS post_author_id
              FROM comments c
              JOIN posts p ON c.post_id = p.id
              WHERE c.id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $comment_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    $row = $result_check->fetch_assoc();
    if ($row['comment_author_id'] == $user_id || $row['post_author_id'] == $user_id) {
        // Usuń komentarz
        $sql_delete = "DELETE FROM comments WHERE id = ?";
        $stmt_delete = $conn->prepare($sql_delete);
        $stmt_delete->bind_param("i", $comment_id);
        $stmt_delete->execute();

        header("Location: forum.php?message=Komentarz został usunięty.");
        exit();
    } else {
        header("Location: forum.php?message=Brak uprawnień do usunięcia komentarza.");
        exit();
    }
} else {
    header("Location: forum.php?message=Komentarz nie istnieje.");
    exit();
}
?>
