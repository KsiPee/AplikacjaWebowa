<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Pobierz wszystkie posty
$sql_posts = "SELECT p.id, p.title, p.content, p.votes, p.created_at, u.name AS author, p.user_id AS post_author_id
              FROM posts p
              JOIN users u ON p.user_id = u.id
              ORDER BY p.votes DESC, p.created_at DESC";
$result_posts = $conn->query($sql_posts);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forum</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #000;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
        h1, h6 {
            color: #000;
        }
        .card {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid #ddd;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .card-title, .card-text {
            color: #000;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #bd2130;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <!-- Nawigacja -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../panel.php">← Powrót do panelu głównego</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center">Forum</h1>
        <a href="create_post.php" class="btn btn-primary mb-4">Dodaj nowy post</a>

        <?php if ($result_posts->num_rows > 0): ?>
            <?php while ($post = $result_posts->fetch_assoc()): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($post['title']); ?></h5>
                        <p class="card-text"><?= htmlspecialchars($post['content']); ?></p>
                        <p class="text-muted">Autor: <?= htmlspecialchars($post['author']); ?>, <?= $post['created_at']; ?></p>
                        <p><strong>Głosy:</strong> <?= $post['votes']; ?></p>
                        <a href="vote.php?post_id=<?= $post['id']; ?>&vote=1" class="btn btn-success">👍</a>
                        <a href="vote.php?post_id=<?= $post['id']; ?>&vote=-1" class="btn btn-danger">👎</a>
                        <?php if ($post['post_author_id'] == $user_id): ?>
                            <a href="delete_post.php?id=<?= $post['id']; ?>" class="btn btn-danger" onclick="return confirm('Czy na pewno chcesz usunąć ten post?')">Usuń</a>
                        <?php endif; ?>

                        <!-- Sekcja komentarzy -->
                        <div class="mt-4">
                            <h6>Komentarze:</h6>
                            <?php
                            $post_id = $post['id'];
                            $sql_comments = "SELECT c.id AS comment_id, c.content, c.created_at, u.name AS author, c.user_id AS comment_author_id
                                             FROM comments c
                                             JOIN users u ON c.user_id = u.id
                                             WHERE c.post_id = ?
                                             ORDER BY c.created_at ASC";
                            $stmt_comments = $conn->prepare($sql_comments);
                            $stmt_comments->bind_param("i", $post_id);
                            $stmt_comments->execute();
                            $result_comments = $stmt_comments->get_result();

                            if ($result_comments->num_rows > 0): ?>
                                <?php while ($comment = $result_comments->fetch_assoc()): ?>
                                    <div class="alert alert-secondary">
                                        <p><?= htmlspecialchars($comment['content']); ?></p>
                                        <p class="text-muted">Autor: <?= htmlspecialchars($comment['author']); ?>, <?= $comment['created_at']; ?></p>
                                        <?php if ($post['post_author_id'] == $user_id || $comment['comment_author_id'] == $user_id): ?>
                                            <a href="delete_comment.php?id=<?= $comment['comment_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Czy na pewno chcesz usunąć ten komentarz?')">Usuń komentarz</a>
                                        <?php endif; ?>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p>Brak komentarzy.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Formularz dodawania komentarza -->
                        <form action="add_comment.php" method="POST" class="mt-3">
                            <input type="hidden" name="post_id" value="<?= $post['id']; ?>">
                            <div class="mb-3">
                                <textarea class="form-control" name="content" rows="2" placeholder="Dodaj komentarz..." required></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm">Dodaj komentarz</button>
                        </form>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-center">Brak postów na forum.</p>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
