<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

// Sprawdź, czy dane zostały przesłane poprawnie
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['post_id']) || !isset($_POST['content'])) {
    header("Location: forum.php?error=Nieprawidłowe dane.");
    exit();
}

// Filtrowanie i walidacja danych wejściowych
$user_id = $_SESSION['user_id'];
$post_id = filter_input(INPUT_POST, 'post_id', FILTER_VALIDATE_INT);
$content = trim(filter_input(INPUT_POST, 'content', FILTER_SANITIZE_STRING));

if (!$post_id || empty($content)) {
    header("Location: forum.php?error=Nieprawidłowe dane lub brak treści komentarza.");
    exit();
}

// Dodaj komentarz do bazy danych
$sql_add_comment = "INSERT INTO comments (post_id, user_id, content, created_at) VALUES (?, ?, ?, NOW())";
$stmt = $conn->prepare($sql_add_comment);
$stmt->bind_param("iis", $post_id, $user_id, $content);

if ($stmt->execute()) {
    header("Location: forum.php?message=Komentarz został dodany.");
} else {
    header("Location: forum.php?error=Nie udało się dodać komentarza.");
}

$stmt->close();
$conn->close();
exit();
