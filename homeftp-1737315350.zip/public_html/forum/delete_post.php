<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

// Pobierz ID posta
$post_id = $_GET['id'] ?? null;

if (!$post_id) {
    header("Location: forum.php?error=Nie znaleziono posta do usunięcia.");
    exit();
}

// Sprawdź, czy użytkownik jest właścicielem posta
$user_id = $_SESSION['user_id'];
$sql_check_owner = "SELECT id FROM posts WHERE id = ? AND user_id = ?";
$stmt_check = $conn->prepare($sql_check_owner);
$stmt_check->bind_param("ii", $post_id, $user_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows === 0) {
    header("Location: forum.php?error=Brak uprawnień do usunięcia tego posta.");
    exit();
}

// Usuń post
$sql_delete = "DELETE FROM posts WHERE id = ?";
$stmt_delete = $conn->prepare($sql_delete);
$stmt_delete->bind_param("i", $post_id);

if ($stmt_delete->execute()) {
    header("Location: forum.php?message=Post został pomyślnie usunięty.");
    exit();
} else {
    header("Location: forum.php?error=Nie udało się usunąć posta.");
    exit();
}
