<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['post_id']) || !isset($_GET['vote'])) {
    header("Location: forum.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$post_id = $_GET['post_id'];
$vote = (int)$_GET['vote'];

// Sprawdź, czy użytkownik już głosował
$sql_check_vote = "SELECT * FROM post_votes WHERE user_id = ? AND post_id = ?";
$stmt_check = $conn->prepare($sql_check_vote);
$stmt_check->bind_param("ii", $user_id, $post_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows > 0) {
    header("Location: forum.php?message=Już głosowałeś na ten post.");
    exit();
}

// Dodaj głos
$sql_vote = "INSERT INTO post_votes (user_id, post_id, vote) VALUES (?, ?, ?)";
$stmt_vote = $conn->prepare($sql_vote);
$stmt_vote->bind_param("iii", $user_id, $post_id, $vote);
$stmt_vote->execute();

// Zaktualizuj liczbę głosów w tabeli postów
$sql_update_votes = "UPDATE posts SET votes = votes + ? WHERE id = ?";
$stmt_update = $conn->prepare($sql_update_votes);
$stmt_update->bind_param("ii", $vote, $post_id);
$stmt_update->execute();

header("Location: forum.php");
exit();
?>
