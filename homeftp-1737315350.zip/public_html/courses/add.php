<?php
session_start();
include '../db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Walidacja i filtrowanie danych wejściowych
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);
    $type = filter_input(INPUT_POST, 'type', FILTER_SANITIZE_STRING);
    $link = filter_input(INPUT_POST, 'link', FILTER_SANITIZE_URL);
    $visibility = filter_input(INPUT_POST, 'visibility', FILTER_SANITIZE_STRING);
    $user_id = $_SESSION['user_id'];

    // Obsługa przesyłania pliku
    $file_path = null;
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        // Dozwolone typy plików
        $allowed_types = [
            'application/pdf', // PDF
            'image/jpeg',      // Obraz JPG
            'image/png',       // Obraz PNG
            'video/mp4'        // Wideo MP4
        ];

        $file_type = mime_content_type($_FILES['file']['tmp_name']);
        if (!in_array($file_type, $allowed_types)) {
            die("Nieprawidłowy typ pliku. Dozwolone są tylko PDF, JPG, PNG i MP4.");
        }

        // Maksymalny rozmiar pliku (np. 5 MB)
        if ($_FILES['file']['size'] > 5 * 1024 * 1024) {
            die("Plik jest za duży. Maksymalny rozmiar to 5 MB.");
        }

        $upload_dir = '../uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true); // Tworzy folder, jeśli nie istnieje
        }

        // Generowanie unikalnej nazwy pliku
        $file_name = uniqid() . '_' . basename($_FILES['file']['name']);
        $file_path = $upload_dir . $file_name;

        // Przeniesienie pliku do folderu uploads
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
            $file_path = 'uploads/' . $file_name; // Zapisujemy ścieżkę względną
        } else {
            die("Wystąpił błąd podczas przesyłania pliku.");
        }
    }

    // Sprawdzenie wymaganych pól
    if (empty($name) || empty($type) || empty($visibility)) {
        die("Proszę wypełnić wszystkie wymagane pola.");
    }

    // Dodanie materiału do bazy danych
    $stmt = $conn->prepare("INSERT INTO courses (name, description, type, link, file_path, visibility, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssi", $name, $description, $type, $link, $file_path, $visibility, $user_id);

    if ($stmt->execute()) {
        header("Location: view.php?message=Materiał został dodany!");
        exit();
    } else {
        $error = "Błąd podczas dodawania materiału: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj materiał edukacyjny</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Dodaj nowy materiał edukacyjny</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="name" class="form-label">Nazwa materiału</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Opis</label>
                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="type" class="form-label">Typ materiału</label>
                <select class="form-select" id="type" name="type" required>
                    <option value="video">Wideo</option>
                    <option value="document">Dokument</option>
                    <option value="image">Zdjęcie</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="link" class="form-label">Link do materiału</label>
                <input type="url" class="form-control" id="link" name="link" placeholder="Opcjonalnie, np. link do YouTube">
            </div>
            <div class="mb-3">
                <label for="file" class="form-label">Prześlij plik (PDF, JPG, PNG, MP4)</label>
                <input type="file" class="form-control" id="file" name="file">
            </div>
            <div class="mb-3">
                <label for="visibility" class="form-label">Widoczność materiału</label>
                <select class="form-select" id="visibility" name="visibility" required>
                    <option value="private">Tylko dla mnie</option>
                    <option value="public">Widoczny dla wszystkich</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Dodaj materiał</button>
        </form>
        <div class="mt-4 text-center">
            <a href="view.php" class="btn btn-secondary">Powrót</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
