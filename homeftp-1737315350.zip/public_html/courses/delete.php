<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Pobierz ścieżkę pliku, aby go usunąć
    $stmt = $conn->prepare("SELECT file_path FROM courses WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row && !empty($row['file_path']) && file_exists('../' . $row['file_path'])) {
        unlink('../' . $row['file_path']); // Usuń plik z serwera
    }

    // Usuń rekord z bazy danych
    $stmt = $conn->prepare("DELETE FROM courses WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: view.php?message=Materiał został usunięty!");
    } else {
        die("Błąd podczas usuwania materiału: " . $conn->error);
    }
} else {
    header("Location: view.php?message=Nie znaleziono materiału do usunięcia.");
}
exit();
