<?php 
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php?message=Musisz być zalogowany, aby przeglądać materiały edukacyjne.");
    exit();
}

$user_id = $_SESSION['user_id'];

// Pobierz materiały edukacyjne widoczne dla użytkownika
$sql = "SELECT * FROM courses WHERE visibility = 'public' OR user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Materiały edukacyjne</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #333;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .card {
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        .btn-custom {
            font-size: 1.1rem;
            font-weight: 600;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
    </style>
</head>
<body>
    <!-- Nawigacja -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../panel.php">← Powrót do panelu głównego</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center mb-4">Materiały edukacyjne</h1>
        <div class="text-center mb-4">
            <a href="add.php" class="btn btn-primary btn-custom">Dodaj nowy materiał</a>
        </div>
        <?php if ($result->num_rows > 0): ?>
            <div class="row mt-4">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body d-flex flex-column justify-content-between">
                                <h5 class="card-title"><?= htmlspecialchars($row['name']); ?></h5>
                                <p class="card-text"><?= htmlspecialchars($row['description']); ?></p>
                                <div class="d-flex justify-content-between mt-3">
                                    <!-- Obsługa linku do pliku na serwerze -->
                                    <?php if (!empty($row['file_path'])): ?>
                                        <a href="../<?= htmlspecialchars($row['file_path']); ?>" target="_blank" class="btn btn-primary btn-custom">Otwórz</a>
                                    <?php endif; ?>
                                    <!-- Obsługa linku zewnętrznego -->
                                    <?php if (!empty($row['link'])): ?>
                                        <a href="<?= htmlspecialchars($row['link']); ?>" target="_blank" class="btn btn-success btn-custom">Zewnętrzny link</a>
                                    <?php endif; ?>
                                    <!-- Przyciski dodatkowe -->
                                    <?php if ($row['user_id'] == $user_id): ?>
                                        <a href="delete.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-custom" onclick="return confirm('Czy na pewno chcesz usunąć ten materiał?')">Usuń</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p class="text-center">Brak dostępnych materiałów edukacyjnych.</p>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
