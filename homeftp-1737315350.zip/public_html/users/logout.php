<?php
session_start();
// Usuń wszystkie zmienne sesji
session_unset();
// Zniszcz sesję
session_destroy();
// Przekieruj na stronę główną
header("Location: ../index.php?message=Zostałeś wylogowany.");
exit();
?>
