<?php
session_start();
include '../db.php';

// Generowanie tokena CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Weryfikacja tokena CSRF
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        die("Nieprawidłowy token CSRF.");
    }

    // Filtrowanie danych wejściowych
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

    // Walidacja hasła po stronie serwera
    if (strlen($password) < 8 || !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
        $message = "Hasło musi mieć co najmniej 8 znaków i zawierać co najmniej jeden znak specjalny.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hashed_password);

        if ($stmt->execute()) {
            // Przekierowanie z opóźnieniem
            echo "
            <!DOCTYPE html>
            <html lang='en'>
            <head>
                <meta charset='UTF-8'>
                <meta name='viewport' content='width=device-width, initial-scale=1.0'>
                <title>Rejestracja zakończona</title>
                <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
                <meta http-equiv='refresh' content='5;url=login.php'>
            </head>
            <body>
                <div class='container mt-5'>
                    <div class='card mx-auto' style='max-width: 500px;'>
                        <div class='card-body text-center'>
                            <h3 class='card-title'>Rejestracja zakończona sukcesem!</h3>
                            <p class='card-text'>Za chwilę zostaniesz przeniesiony na stronę logowania.</p>
                            <p class='card-text'><a href='login.php'>Kliknij tutaj, jeśli przekierowanie nie nastąpi.</a></p>
                        </div>
                    </div>
                </div>
            </body>
            </html>
            ";
            exit();
        } else {
            $message = "Błąd: " . htmlspecialchars($conn->error, ENT_QUOTES, 'UTF-8');
        }

        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestracja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function validatePassword() {
            const password = document.getElementById('password').value;
            const messageElement = document.getElementById('passwordMessage');
            const specialCharRegex = /[!@#$%^&*(),.?":{}|<>]/;

            if (password.length < 8 || !specialCharRegex.test(password)) {
                messageElement.textContent = "Hasło musi mieć co najmniej 8 znaków i zawierać co najmniej jeden znak specjalny.";
                return false;
            }

            messageElement.textContent = "";
            return true;
        }
    </script>
</head>
<body>
    <!-- Nawigacja -->
    <nav class="navbar navbar-light bg-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../index.php">← Powrót do strony głównej</a>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="card mx-auto" style="max-width: 500px;">
            <div class="card-body">
                <h3 class="card-title text-center">Zarejestruj się</h3>
                <?php if (isset($message)): ?>
                    <div class="alert alert-danger text-center"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
                <form method="POST" onsubmit="return validatePassword();">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8'); ?>">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nazwa użytkownika</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Hasło</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div id="passwordMessage" class="text-danger mt-1"></div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Zarejestruj się</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
