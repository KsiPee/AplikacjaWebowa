<?php
session_start();
include '../db.php';

// Sprawdzenie, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Walidacja i filtrowanie danych wejściowych
    $user_id = $_SESSION['user_id'];
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $due_date = filter_input(INPUT_POST, 'due_date', FILTER_SANITIZE_STRING);
    $status = 'not started';

    // Sprawdzenie wymaganych pól
    if (empty($name)) {
        $error = "Nazwa celu jest wymagana.";
    } elseif ($due_date && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $due_date)) {
        $error = "Nieprawidłowy format daty. Użyj formatu YYYY-MM-DD.";
    } else {
        // Przygotowanie zapytania SQL
        $stmt = $conn->prepare("INSERT INTO goals (user_id, name, due_date, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $user_id, $name, $due_date, $status);

        if ($stmt->execute()) {
            header("Location: view.php?message=Cel został dodany!");
            exit();
        } else {
            $error = "Błąd podczas dodawania celu: " . $conn->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj cel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Dodaj nowy cel edukacyjny</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Nazwa celu</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="due_date" class="form-label">Data zakończenia</label>
                <input type="date" class="form-control" id="due_date" name="due_date">
            </div>
            <button type="submit" class="btn btn-primary w-100">Dodaj cel</button>
        </form>
        <div class="mt-4 text-center">
            <a href="view.php" class="btn btn-secondary">Powrót</a>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
