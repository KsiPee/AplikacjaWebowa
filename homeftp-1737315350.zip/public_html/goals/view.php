<?php 
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

// Generowanie tokenu CSRF, jeśli jeszcze nie istnieje
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$user_id = $_SESSION['user_id'];
$sql = "SELECT * FROM goals WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twoje cele edukacyjne</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #000;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
        .btn-custom {
            font-size: 1.1rem;
            font-weight: 600;
        }
        .list-group-item {
            background: rgba(255, 255, 255, 0.9);
            color: #000;
        }
        h1, h5, p {
            color: #000;
        }
    </style>
</head>
<body>
    <!-- Nawigacja -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../panel.php">← Powrót do panelu głównego</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center mb-4">Twoje cele edukacyjne</h1>

        <!-- Przyciski i lista celów -->
        <div class="text-center mb-4">
            <a href="add.php" class="btn btn-primary btn-custom">Dodaj nowy cel</a>
        </div>

        <?php if ($result->num_rows > 0): ?>
            <ul class="list-group mt-4">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <div>
                            <h5><?= htmlspecialchars($row['name']); ?></h5>
                            <p>Termin: <?= htmlspecialchars($row['due_date']); ?></p>
                            <span class="badge bg-<?= $row['status'] === 'completed' ? 'success' : ($row['status'] === 'in progress' ? 'warning' : 'secondary'); ?>">
                                <?= htmlspecialchars($row['status']); ?>
                            </span>
                        </div>
                        <div>
                            <?php if ($row['status'] !== 'completed'): ?>
                                <a href="mark_completed.php?id=<?= $row['id']; ?>&csrf_token=<?= $_SESSION['csrf_token']; ?>" 
                                   class="btn btn-success btn-sm">Oznacz jako ukończone</a>
                            <?php endif; ?>
                            <a href="delete.php?id=<?= $row['id']; ?>&csrf_token=<?= $_SESSION['csrf_token']; ?>" 
                               class="btn btn-danger btn-sm" 
                               onclick="return confirm('Czy na pewno chcesz usunąć ten cel?')">Usuń</a>
                        </div>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p class="text-center">Nie masz jeszcze żadnych celów edukacyjnych.</p>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
