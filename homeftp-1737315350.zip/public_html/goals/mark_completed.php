<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

// Sprawdź, czy żądanie GET jest poprawne
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Walidacja parametrów
    if (!isset($_GET['id'])) {
        die("Nie przekazano ID celu.");
    }
    if (!isset($_GET['csrf_token'])) {
        die("Brak tokenu CSRF.");
    }
    if ($_GET['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Token CSRF jest nieprawidłowy.");
    }

    // Filtrowanie danych wejściowych
    $goal_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if (!$goal_id) {
        die("Nieprawidłowy identyfikator celu.");
    }

    $user_id = $_SESSION['user_id'];

    // Sprawdzenie, czy cel istnieje w bazie danych
    $sql_check_goal = "SELECT id FROM goals WHERE id = ? AND user_id = ?";
    $stmt_check_goal = $conn->prepare($sql_check_goal);
    $stmt_check_goal->bind_param("ii", $goal_id, $user_id);
    $stmt_check_goal->execute();
    $result_check_goal = $stmt_check_goal->get_result();

    if ($result_check_goal->num_rows === 0) {
        die("Nie znaleziono celu w bazie danych.");
    }

    // Aktualizacja statusu celu
    $sql_update_goal = "UPDATE goals SET status = 'completed' WHERE id = ? AND user_id = ?";
    $stmt_update_goal = $conn->prepare($sql_update_goal);
    $stmt_update_goal->bind_param("ii", $goal_id, $user_id);

    if ($stmt_update_goal->execute()) {
        header("Location: view.php?message=Cel został oznaczony jako ukończony!");
    } else {
        die("Błąd podczas aktualizacji statusu.");
    }

    $stmt_update_goal->close();
    $stmt_check_goal->close();
} else {
    die("Nieprawidłowe żądanie.");
}

$conn->close();
exit();
