<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

if (isset($_GET['id'])) {
    $goal_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Usunięcie celu
    $sql = "DELETE FROM goals WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $goal_id, $user_id);

    if ($stmt->execute()) {
        header("Location: view.php?message=Cel został usunięty.");
    } else {
        die("Błąd podczas usuwania celu: " . $conn->error);
    }
} else {
    header("Location: view.php?message=Nie znaleziono celu do usunięcia.");
}
exit();
