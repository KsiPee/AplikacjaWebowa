<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona główna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('background.jpg') no-repeat center center fixed; 
            background-size: cover;
            color: #fff;
        }
        .overlay {
            background: rgba(0, 0, 0, 0.5); /* Ciemny przezroczysty overlay */
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }
        .card {
            background: rgba(255, 255, 255, 0.9);
            border: none;
        }
    </style>
</head>
<body>
    <div class="overlay">
        <div class="container">
            <div class="card mx-auto p-4" style="max-width: 600px;">
                <h1 class="text-center">Witamy w aplikacji edukacyjnej</h1>
                <p class="text-center">Wspieraj swój rozwój poprzez monitorowanie postępów, planowanie nauki i korzystanie z materiałów edukacyjnych.</p>
                <div class="d-grid gap-2 mt-4">
                    <a href="users/register.php" class="btn btn-primary btn-lg">Zarejestruj się</a>
                    <a href="users/login.php" class="btn btn-secondary btn-lg">Zaloguj się</a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
