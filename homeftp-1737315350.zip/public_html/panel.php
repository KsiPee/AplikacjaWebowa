<?php
session_start();

// Ustaw czas wygaśnięcia sesji (np. 15 minut = 900 sekund)
$timeout_duration = 900;

// Sprawdź czas ostatniej aktywności
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: users/login.php?message=Twoja sesja wygasła.");
    exit();
}

// Zaktualizuj czas ostatniej aktywności
$_SESSION['LAST_ACTIVITY'] = time();

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: users/login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel użytkownika</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('images/background.jpg') no-repeat center center fixed;
            background-size: cover;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
        .card {
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.15);
        }
        .btn-custom {
            font-size: 1.1rem;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="users/logout.php">Wyloguj się</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center mb-4">Witaj, <?= htmlspecialchars($_SESSION['user_name']); ?>!</h1>
        <p class="text-center text-muted">Zarządzaj swoimi postępami, materiałami edukacyjnymi, testami i więcej.</p>
        
        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Postępy</h5>
                        <p class="card-text">Przeglądaj swoje wyniki i osiągnięcia.</p>
                        <a href="progress/view.php" class="btn btn-primary btn-custom">Zobacz postępy</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Materiały edukacyjne</h5>
                        <p class="card-text">Przeglądaj dostępne materiały edukacyjne.</p>
                        <a href="courses/view.php" class="btn btn-success btn-custom">Przeglądaj materiały</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Cele edukacyjne</h5>
                        <p class="card-text">Planuj swoje cele i śledź ich realizację.</p>
                        <a href="goals/view.php" class="btn btn-warning btn-custom">Zobacz cele</a>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Testy</h5>
                        <p class="card-text">Przejdź do testów i sprawdź swoją wiedzę.</p>
                        <a href="tests/select.php" class="btn btn-info btn-custom">Rozpocznij testy</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Twórz testy</h5>
                        <p class="card-text">Dodaj nowy test i pytania.</p>
                        <a href="tests/create_test.php" class="btn btn-secondary btn-custom">Twórz test</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <h5 class="card-title">Forum</h5>
                        <p class="card-text">Dołącz do dyskusji i dziel się materiałami.</p>
                        <a href="forum/forum.php" class="btn btn-dark btn-custom">Przejdź na forum</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
