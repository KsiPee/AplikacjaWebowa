<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$test_id = $_GET['id'] ?? null;

if (!$test_id) {
    header("Location: select.php");
    exit();
}

// Sprawdź, czy użytkownik jest właścicielem testu
$sql_check_owner = "SELECT id FROM tests WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql_check_owner);
if (!$stmt) {
    die("Błąd przygotowania zapytania: " . $conn->error);
}
$stmt->bind_param("ii", $test_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: select.php?message=Nie masz uprawnień do usunięcia tego testu.");
    exit();
}

// Usuń pytania powiązane z testem
$sql_delete_questions = "DELETE FROM questions WHERE test_id = ?";
$stmt = $conn->prepare($sql_delete_questions);
if (!$stmt) {
    die("Błąd przygotowania zapytania: " . $conn->error);
}
$stmt->bind_param("i", $test_id);
if (!$stmt->execute()) {
    die("Błąd usuwania pytań: " . $stmt->error);
}

// Usuń test
$sql_delete_test = "DELETE FROM tests WHERE id = ?";
$stmt = $conn->prepare($sql_delete_test);
if (!$stmt) {
    die("Błąd przygotowania zapytania: " . $conn->error);
}
$stmt->bind_param("i", $test_id);
if ($stmt->execute()) {
    header("Location: select.php?message=Test został usunięty.");
    exit();
} else {
    die("Błąd wykonania zapytania: " . $stmt->error);
}
?>
