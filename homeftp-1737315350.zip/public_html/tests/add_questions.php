<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$test_id = $_GET['test_id'] ?? null;

if (!$test_id) {
    header("Location: ../panel.php");
    exit();
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $question = $_POST['question'];
    $type = $_POST['type'];
    $option_a = $_POST['option_a'] ?? null;
    $option_b = $_POST['option_b'] ?? null;
    $option_c = $_POST['option_c'] ?? null;
    $option_d = $_POST['option_d'] ?? null;
    $correct_option = isset($_POST['correct_option']) ? implode(",", $_POST['correct_option']) : null;

    $stmt = $conn->prepare("INSERT INTO questions (test_id, question, type, option_a, option_b, option_c, option_d, correct_option) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssss", $test_id, $question, $type, $option_a, $option_b, $option_c, $option_d, $correct_option);

    if ($stmt->execute()) {
        header("Location: add_questions.php?test_id=$test_id&message=Pytanie dodane pomyślnie!");
        exit();
    } else {
        $error = "Nie udało się dodać pytania: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj pytanie</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const typeSelect = document.getElementById('type');
            const optionsDiv = document.getElementById('options');
            const correctOptionDiv = document.getElementById('correct-option');

            function updateOptions() {
                const type = typeSelect.value;
                const optionFields = optionsDiv.querySelectorAll('.option-field');

                // Reset widoczności wszystkich pól
                optionFields.forEach(field => field.style.display = 'block');
                correctOptionDiv.innerHTML = '';

                if (type === 'true_false') {
                    optionFields.forEach(field => field.style.display = 'none');
                    correctOptionDiv.innerHTML = `
                        <label class="form-label">Poprawna odpowiedź</label>
                        <div>
                            <label><input type="radio" name="correct_option[]" value="true" required> Prawda</label>
                            <label><input type="radio" name="correct_option[]" value="false"> Fałsz</label>
                        </div>
                    `;
                } else if (type === 'multiple_choice') {
                    correctOptionDiv.innerHTML = `
                        <label class="form-label">Poprawne odpowiedzi</label>
                        <div>
                            <label><input type="checkbox" name="correct_option[]" value="A"> A</label>
                            <label><input type="checkbox" name="correct_option[]" value="B"> B</label>
                            <label><input type="checkbox" name="correct_option[]" value="C"> C</label>
                            <label><input type="checkbox" name="correct_option[]" value="D"> D</label>
                        </div>
                    `;
                } else {
                    correctOptionDiv.innerHTML = `
                        <label class="form-label">Poprawna odpowiedź</label>
                        <div>
                            <label><input type="radio" name="correct_option[]" value="A" required> A</label>
                            <label><input type="radio" name="correct_option[]" value="B"> B</label>
                            <label><input type="radio" name="correct_option[]" value="C"> C</label>
                            <label><input type="radio" name="correct_option[]" value="D"> D</label>
                        </div>
                    `;
                }
            }

            // Uruchomienie funkcji przy załadowaniu
            updateOptions();

            // Aktualizacja opcji po zmianie typu
            typeSelect.addEventListener('change', updateOptions);
        });
    </script>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Dodaj pytanie do testu</h1>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="question" class="form-label">Treść pytania</label>
                <textarea class="form-control" id="question" name="question" rows="3" required><?= htmlspecialchars($_POST['question'] ?? '') ?></textarea>
            </div>
            <div class="mb-3">
                <label for="type" class="form-label">Typ pytania</label>
                <select class="form-select" id="type" name="type" required>
                    <option value="single_choice" <?= ($_POST['type'] ?? '') === 'single_choice' ? 'selected' : '' ?>>Pojedynczy wybór</option>
                    <option value="multiple_choice" <?= ($_POST['type'] ?? '') === 'multiple_choice' ? 'selected' : '' ?>>Wielokrotny wybór</option>
                    <option value="true_false" <?= ($_POST['type'] ?? '') === 'true_false' ? 'selected' : '' ?>>Prawda/Fałsz</option>
                </select>
            </div>
            <div id="options">
                <div class="mb-3 option-field">
                    <label for="option_a" class="form-label">Opcja A</label>
                    <input type="text" class="form-control" id="option_a" name="option_a" value="<?= htmlspecialchars($_POST['option_a'] ?? '') ?>">
                </div>
                <div class="mb-3 option-field">
                    <label for="option_b" class="form-label">Opcja B</label>
                    <input type="text" class="form-control" id="option_b" name="option_b" value="<?= htmlspecialchars($_POST['option_b'] ?? '') ?>">
                </div>
                <div class="mb-3 option-field">
                    <label for="option_c" class="form-label">Opcja C</label>
                    <input type="text" class="form-control" id="option_c" name="option_c" value="<?= htmlspecialchars($_POST['option_c'] ?? '') ?>">
                </div>
                <div class="mb-3 option-field">
                    <label for="option_d" class="form-label">Opcja D</label>
                    <input type="text" class="form-control" id="option_d" name="option_d" value="<?= htmlspecialchars($_POST['option_d'] ?? '') ?>">
                </div>
            </div>
            <div id="correct-option" class="mb-3"></div>
            <button type="submit" class="btn btn-primary w-100">Dodaj pytanie</button>
            <a href="select.php" class="btn btn-danger w-100 mt-3">Zakończ tworzenie testu</a>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
