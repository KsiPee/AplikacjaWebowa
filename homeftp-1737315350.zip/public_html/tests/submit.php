<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

// Sprawdź, czy żądanie jest POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Żądanie musi być typu POST.");
}

$user_id = $_SESSION['user_id'];
$test_id = $_POST['test_id'];
$answers = $_POST['answers'] ?? [];

// Sprawdź, czy dane zostały przesłane poprawnie
if (empty($test_id)) {
    die("Brak wymaganych danych: test_id.");
}

// Pobierz pytania wraz z poprawnymi odpowiedziami i typem pytania
$sql_questions = "SELECT id, type, correct_option FROM questions WHERE test_id = ?";
$stmt_questions = $conn->prepare($sql_questions);
$stmt_questions->bind_param("i", $test_id);
$stmt_questions->execute();
$result_questions = $stmt_questions->get_result();

// Oblicz wynik testu
$total_questions = 0;
$correct_answers = 0;

while ($row = $result_questions->fetch_assoc()) {
    $total_questions++;
    $question_id = $row['id'];
    $type = $row['type'];
    $correct_option = $row['correct_option'];

    // Sprawdź, czy użytkownik odpowiedział na to pytanie
    if (!isset($answers[$question_id]) || empty($answers[$question_id])) {
        continue; // Jeśli brak odpowiedzi, przejdź do kolejnego pytania
    }

    $user_answer = $answers[$question_id];

    if ($type === 'true_false') {
        // Pytanie typu Prawda/Fałsz
        if ($user_answer === $correct_option) {
            $correct_answers++;
        }
    } elseif ($type === 'multiple_choice') {
        // Pytanie typu Wielokrotny wybór
        $correct_array = explode(',', $correct_option); // Zamień poprawne odpowiedzi na tablicę
        $user_array = is_array($user_answer) ? $user_answer : explode(',', $user_answer); // Zamień odpowiedzi użytkownika na tablicę
        sort($correct_array); // Posortuj tablice
        sort($user_array);

        if ($correct_array === $user_array) {
            $correct_answers++;
        }
    } else {
        // Pytanie typu Pojedynczy wybór
        if ($user_answer === $correct_option) {
            $correct_answers++;
        }
    }
}

$score = ($total_questions > 0) ? ($correct_answers / $total_questions) * 100 : 0;

// Zapisz wynik w tabeli progress
$sql_insert_progress = "INSERT INTO progress (user_id, test_id, completion, date_completed) 
                        VALUES (?, ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE 
                        completion = VALUES(completion), 
                        date_completed = NOW()";
$stmt_progress = $conn->prepare($sql_insert_progress);
$stmt_progress->bind_param("iid", $user_id, $test_id, $score);
$stmt_progress->execute();

// Dodaj osiągnięcia na podstawie wyniku testu
$achievement_name = "Ukończenie testu";
$achievement_desc = "Zdobyłeś wynik " . round($score, 2) . "% w teście.";
$level = '';
$points = round($score);

if ($score >= 80 && $score < 90) {
    $level = 'Bronze';
} elseif ($score >= 90 && $score < 100) {
    $level = 'Silver';
} elseif ($score == 100) {
    $level = 'Gold';
}

if (!empty($level)) {
    $sql_achievement = "INSERT INTO achievements (user_id, name, description, category, level, points, earned_at) 
                        VALUES (?, ?, ?, 'Test Completion', ?, ?, NOW())
                        ON DUPLICATE KEY UPDATE 
                        points = GREATEST(points, VALUES(points)), 
                        level = VALUES(level), 
                        earned_at = NOW()";
    $stmt_achievement = $conn->prepare($sql_achievement);
    $stmt_achievement->bind_param("isssi", $user_id, $achievement_name, $achievement_desc, $level, $points);
    $stmt_achievement->execute();
}

// Przekierowanie z wynikiem
header("Location: ../progress/view.php?message=Test zakończony! Twój wynik to " . round($score, 2) . "%.");
exit();