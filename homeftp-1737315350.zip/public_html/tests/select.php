<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Pobierz dostępne testy widoczne dla użytkownika
$sql_tests = "SELECT id, name, description, visibility, user_id 
              FROM tests 
              WHERE visibility = 'public' OR (visibility = 'private' AND user_id = ?)";
$stmt = $conn->prepare($sql_tests);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_tests = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wybór testu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #000; /* Tekst w kolorze czarnym */
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
        .card {
            background: rgba(255, 255, 255, 0.9);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .card-title, .card-text {
            color: #000; /* Kolor tekstu na kartach */
        }
        h1, p {
            color: #000; /* Kolor nagłówków i paragrafów */
        }
    </style>
</head>
<body>
    <!-- Nawigacja -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../panel.php">← Powrót do panelu głównego</a>
        </div>
    </nav>

    <div class="container">
        <h1 class="text-center mb-4">Wybierz test</h1>
        <div class="row mt-4">
            <?php if ($result_tests->num_rows > 0): ?>
                <?php while ($row = $result_tests->fetch_assoc()): ?>
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($row['name']); ?></h5>
                                <p class="card-text"><?= htmlspecialchars($row['description']); ?></p>
                                <p class="card-text">
                                    <small class="text-muted">
                                        Widoczność: <?= htmlspecialchars($row['visibility'] === 'public' ? 'Publiczna' : 'Prywatna'); ?>
                                    </small>
                                </p>
                                <div class="d-flex justify-content-between">
                                    <!-- Sprawdzenie, czy test ma pytania -->
                                    <?php
                                    $test_id = $row['id'];
                                    $sql_check_questions = "SELECT COUNT(*) AS question_count FROM questions WHERE test_id = ?";
                                    $stmt_check = $conn->prepare($sql_check_questions);
                                    $stmt_check->bind_param("i", $test_id);
                                    $stmt_check->execute();
                                    $result_check = $stmt_check->get_result();
                                    $check_row = $result_check->fetch_assoc();
                                    if ($check_row['question_count'] > 0): ?>
                                        <a href="start.php?test_id=<?= $row['id']; ?>" class="btn btn-primary">Rozpocznij test</a>
                                    <?php else: ?>
                                        <a href="#" class="btn btn-secondary disabled" title="Test nie zawiera pytań">Brak pytań</a>
                                    <?php endif; ?>
                                    <?php if ($row['user_id'] == $user_id): ?>
                                        <a href="delete.php?id=<?= $row['id']; ?>" class="btn btn-danger" onclick="return confirm('Czy na pewno chcesz usunąć ten test?')">Usuń</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p class="text-center">Brak dostępnych testów.</p>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
