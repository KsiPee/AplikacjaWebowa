<?php
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$test_id = $_GET['test_id'] ?? null;

if (!$test_id) {
    header("Location: select.php");
    exit();
}

// Sprawdź, czy użytkownik ma dostęp do tego testu
$sql_test_access = "SELECT id FROM tests WHERE id = ? AND (visibility = 'public' OR user_id = ?)";
$stmt = $conn->prepare($sql_test_access);
$stmt->bind_param("ii", $test_id, $user_id);
$stmt->execute();
$result_access = $stmt->get_result();

if ($result_access->num_rows === 0) {
    header("Location: select.php?message=Nie masz dostępu do tego testu.");
    exit();
}

// Pobierz pytania do testu
$sql_questions = "SELECT id, question, option_a, option_b, option_c, option_d, type FROM questions WHERE test_id = ?";
$stmt = $conn->prepare($sql_questions);
$stmt->bind_param("i", $test_id);
$stmt->execute();
$result_questions = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rozpocznij test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        let preventUnload = true; // Flaga kontrolująca opuszczenie strony

        // Blokowanie cofania się na stronie
        window.history.pushState(null, "", window.location.href);
        window.onpopstate = function () {
            if (confirm("Jeśli cofniesz się, test zostanie niezaliczony. Czy na pewno chcesz opuścić test?")) {
                preventUnload = false; // Pozwól opuścić stronę
                window.history.back();
            } else {
                window.history.pushState(null, "", window.location.href);
            }
        };

        // Ostrzeżenie przed opuszczeniem strony
        window.addEventListener("beforeunload", function (e) {
            if (preventUnload) {
                e.preventDefault();
                e.returnValue = "Czy na pewno chcesz opuścić test? Twoje odpowiedzi nie zostaną zapisane.";
            }
        });

        // Funkcja wyłączająca ostrzeżenie przy naciśnięciu "Zakończ test"
        function disableUnloadWarning() {
            preventUnload = false;
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Rozpocznij test</h1>
        <form action="submit.php" method="POST" onsubmit="disableUnloadWarning()">
            <input type="hidden" name="test_id" value="<?= htmlspecialchars($test_id); ?>">
            <?php if ($result_questions->num_rows > 0): ?>
                <?php while ($row = $result_questions->fetch_assoc()): ?>
                    <div class="mb-4">
                        <h5><?= htmlspecialchars($row['question']); ?></h5>
                        <div>
                            <?php if ($row['type'] === 'true_false'): ?>
                                <label><input type="radio" name="answers[<?= $row['id']; ?>]" value="true" required> Prawda</label><br>
                                <label><input type="radio" name="answers[<?= $row['id']; ?>]" value="false"> Fałsz</label>
                            <?php elseif ($row['type'] === 'multiple_choice'): ?>
                                <label><input type="checkbox" name="answers[<?= $row['id']; ?>][]" value="A"> <?= htmlspecialchars($row['option_a']); ?></label><br>
                                <label><input type="checkbox" name="answers[<?= $row['id']; ?>][]" value="B"> <?= htmlspecialchars($row['option_b']); ?></label><br>
                                <label><input type="checkbox" name="answers[<?= $row['id']; ?>][]" value="C"> <?= htmlspecialchars($row['option_c']); ?></label><br>
                                <label><input type="checkbox" name="answers[<?= $row['id']; ?>][]" value="D"> <?= htmlspecialchars($row['option_d']); ?></label>
                            <?php else: ?>
                                <label><input type="radio" name="answers[<?= $row['id']; ?>]" value="A" required> <?= htmlspecialchars($row['option_a']); ?></label><br>
                                <label><input type="radio" name="answers[<?= $row['id']; ?>]" value="B"> <?= htmlspecialchars($row['option_b']); ?></label><br>
                                <label><input type="radio" name="answers[<?= $row['id']; ?>]" value="C"> <?= htmlspecialchars($row['option_c']); ?></label><br>
                                <label><input type="radio" name="answers[<?= $row['id']; ?>]" value="D"> <?= htmlspecialchars($row['option_d']); ?></label>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
                <button type="submit" class="btn btn-success w-100">Zakończ test</button>
            <?php else: ?>
                <p class="text-center">Brak pytań do tego testu.</p>
            <?php endif; ?>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
