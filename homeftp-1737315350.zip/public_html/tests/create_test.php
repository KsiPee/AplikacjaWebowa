<?php  
session_start();
include '../db.php';

// Sprawdź, czy użytkownik jest zalogowany
if (!isset($_SESSION['user_id'])) {
    header("Location: ../users/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Walidacja i filtrowanie danych wejściowych
    $user_id = $_SESSION['user_id'];
    $test_name = filter_input(INPUT_POST, 'test_name', FILTER_SANITIZE_STRING);
    $test_description = filter_input(INPUT_POST, 'test_description', FILTER_SANITIZE_STRING);
    $visibility = filter_input(INPUT_POST, 'visibility', FILTER_SANITIZE_STRING);

    // Walidacja danych
    if (empty($test_name)) {
        $error = "Nazwa testu jest wymagana.";
    } elseif (empty($test_description)) {
        $error = "Opis testu jest wymagany.";
    } elseif (!in_array($visibility, ['private', 'public'])) {
        $error = "Nieprawidłowa wartość dla pola widoczności.";
    } else {
        // Dodaj test do bazy danych
        $stmt = $conn->prepare("INSERT INTO tests (name, description, visibility, user_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $test_name, $test_description, $visibility, $user_id);

        if ($stmt->execute()) {
            $test_id = $stmt->insert_id;
            header("Location: add_questions.php?test_id=$test_id");
            exit();
        } else {
            $error = "Nie udało się dodać testu: " . $conn->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dodaj nowy test</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: url('../images/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: #000;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            margin-top: 50px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
        }
        h1, label {
            color: #000;
        }
        .form-control, .form-select {
            background: rgba(255, 255, 255, 0.85);
            border: 1px solid #ced4da;
            color: #000;
        }
        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Nawigacja -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <a class="navbar-brand" href="../panel.php">← Powrót do panelu głównego</a>
        </div>
    </nav>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Dodaj nowy test</h1>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="test_name" class="form-label">Nazwa testu</label>
                <input type="text" class="form-control" id="test_name" name="test_name" required>
            </div>
            <div class="mb-3">
                <label for="test_description" class="form-label">Opis testu</label>
                <textarea class="form-control" id="test_description" name="test_description" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="visibility" class="form-label">Widoczność testu</label>
                <select class="form-select" id="visibility" name="visibility" required>
                    <option value="private">Tylko dla mnie</option>
                    <option value="public">Widoczny dla wszystkich</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary w-100">Dodaj test</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
